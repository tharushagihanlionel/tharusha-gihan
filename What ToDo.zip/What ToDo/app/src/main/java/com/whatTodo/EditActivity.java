package com.whatTodo;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class EditActivity extends AppCompatActivity{
	
	private EditText edit1,edit2;
	private Button button;
	private DatabaseClass databaseClass;
	
	
		
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_edit);
		getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.action)));
		
		edit1 = findViewById(R.id.title);
		edit2 = findViewById(R.id.work);
		button = findViewById(R.id.edit);
		
		databaseClass = new DatabaseClass(this);
		
		final String id = getIntent().getStringExtra("id");
		
		ModleClass modleClass = databaseClass.singleWork(Integer.parseInt(id));
		
		
		edit1.setText(modleClass.getTitle());
		edit2.setText(modleClass.getWork());
		
		button.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v) {
				
				String title = edit1.getText().toString();
				String work = edit2.getText().toString();
				
				ModleClass modleClass = new ModleClass(Integer.parseInt(id), title, work);
				
				int column = databaseClass.updateWork(modleClass);
				
				startActivity(new Intent(getApplicationContext(), MainActivity.class));
			}
			
		});
		
	}
	


}