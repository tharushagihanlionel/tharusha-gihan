package com.whatTodo;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
	
	ListView listView;
	
	List<ModleClass> list;
	
	DatabaseClass databaseClass;
	
	WorkAdapter workAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.action)));
		
		list = new ArrayList<>();
		
		databaseClass = new DatabaseClass(this);
		
		list = databaseClass.getWork();
		
		workAdapter = new WorkAdapter(this, R.layout.single_row, list);
		
		
		listView = findViewById(R.id.listView);
		
		listView.setAdapter(workAdapter);
		
		listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
			
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				
				
				ModleClass modleClass = list.get(position);
				
				AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
				
				builder.setTitle(modleClass.getTitle());
				
				builder.setMessage(modleClass.getWork());
				
				builder.setNegativeButton("Delete", new DialogInterface.OnClickListener(){
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						
						databaseClass.deleteWork(modleClass.getId());
						
						startActivity(new Intent(getApplicationContext(), MainActivity.class));
					}
					
				});
				
				builder.setNeutralButton("Update", new DialogInterface.OnClickListener(){
					
					
					@Override
					public void onClick(DialogInterface arg0, int arg1) {
						
						Intent update = new Intent(MainActivity.this, EditActivity.class);
						update.putExtra("id", String.valueOf(modleClass.getId()));
						startActivity(update);
						
					}
					
				});
				
				builder.show();
			
			}
			
		});
		
		
    }
	
	public void gotoAdd(View v){
		
		startActivity(new Intent(getApplicationContext(), AddWork.class));
	}
}