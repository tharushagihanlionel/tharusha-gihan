package com.whatTodo;

public class ModleClass {
	
	
	String title, work;
	int id;
	
	ModleClass(){
		
		
	}
	
	ModleClass(int id,String title, String work){
		
		this.id = id;
		this.title = title;
		this.work = work;
		
	}
	
	ModleClass(String title, String work){
		
		this.title = title;
		this.work = work;
		
	}
	
	public void setId(int id){
		
		this.id = id;
		
	}
	
	public int getId(){
		
		return  id;
	}
	
	public void setTitle(String title){
		
		this.title = title;
	}
	
	public String getTitle(){
		
		
		return title;
	}
	
	public void setWork(String work){
		
		this.work = work;
	}
	
	public String getWork(){
		
		
		return work;
	}
	
}