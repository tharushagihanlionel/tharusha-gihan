package com.whatTodo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.Currency;
import java.util.List;

public class DatabaseClass extends SQLiteOpenHelper {

	private static final String DB_NAME = "Work.db";
	private static final String TABLE_NAME = "work";
	private static final int VERSION = 1;

	//column names

	private static final String TITLE = "title";
	private static final String WORK = "work";
	private static final String ID = "id";

	DatabaseClass(Context context) {

		super(context, DB_NAME, null, VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {

		String CREATE_TABLE_QUERY = "create table " + TABLE_NAME + "( " + ID + " integer primary key autoincrement,"
				+ TITLE + " text," + WORK + " text );";

		db.execSQL(CREATE_TABLE_QUERY);

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

		String DROP_TABLE = "drop table if exists" + TABLE_NAME;

		db.execSQL(DROP_TABLE);

		onCreate(db);
	}

	public void insertWork(ModleClass modleClass) {

		SQLiteDatabase db = getWritableDatabase();

		ContentValues contentValues = new ContentValues();

		contentValues.put(TITLE, modleClass.getTitle());

		contentValues.put(WORK, modleClass.getWork());

		db.insert(TABLE_NAME, null, contentValues);

		db.close();

	}

	public List<ModleClass> getWork() {

		List<ModleClass> list = new ArrayList<>();

		SQLiteDatabase db = getReadableDatabase();

		String GET_QUERY = "select * from " + TABLE_NAME;

		Cursor cursor = db.rawQuery(GET_QUERY, null);

		if (cursor.moveToFirst()) {

			do {

				ModleClass modleClass = new ModleClass();

				modleClass.setId(cursor.getInt(0));
				modleClass.setTitle(cursor.getString(1));
				modleClass.setWork(cursor.getString(2));

				list.add(modleClass);

			} while (cursor.moveToNext());
		}

		return list;
	}

	public void deleteWork(int id) {

		SQLiteDatabase sQLiteDatabase = getWritableDatabase();

		sQLiteDatabase.delete(TABLE_NAME, ID + " =?", new String[] { String.valueOf(id) });

		sQLiteDatabase.close();
	}

	public ModleClass singleWork(int id) {
		SQLiteDatabase sQLiteDatabase = getWritableDatabase();

		Cursor cursor = sQLiteDatabase.query(TABLE_NAME, new String[] {ID, TITLE, WORK }, ID + " = ?", new String[] { String.valueOf(id) }, null, null, null);

		ModleClass modleClass;

		if (cursor != null) {
			
			cursor.moveToFirst();

			modleClass = new ModleClass(cursor.getInt(0), cursor.getString(1), cursor.getString(2));

			return modleClass;
		}

		return null;
	}


	public int updateWork(ModleClass modleClass){
		
		SQLiteDatabase db = getWritableDatabase();

		ContentValues contentValues = new ContentValues();

		contentValues.put(TITLE, modleClass.getTitle());

		contentValues.put(WORK, modleClass.getWork());
		
		int column = db.update(TABLE_NAME, contentValues, ID + " =?", new String[]{String.valueOf(modleClass.getId())});
			
		db.close();
					
		return  column;
	}
}