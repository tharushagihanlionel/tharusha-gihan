package com.whatTodo;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class AddWork extends AppCompatActivity{
	
	EditText edit1,edit2;
	
	DatabaseClass databaseClass;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_add);
		
		getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.action)));
		
		databaseClass = new DatabaseClass(this);
		
		edit1 = findViewById(R.id.title);
		edit2 = findViewById(R.id.work);
		
	}
	
	public void add(View view){
		
		String title = edit1.getText().toString();
		String work  = edit2.getText().toString();
		
		ModleClass modleClass = new ModleClass(title, work);
		
		databaseClass.insertWork(modleClass);
		
		startActivity(new Intent(getApplicationContext(), MainActivity.class));
		
		
	}
	
}