package com.whatTodo;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import java.util.List;

public class WorkAdapter extends ArrayAdapter{
	
	private Context context;
	private int resouce;
	private List<ModleClass> list;
	
	WorkAdapter(Context context, int resouce, List<ModleClass> list){
		
		super(context, resouce, list);
		
		this.context = context;
		this.list = list;
		this.resouce = resouce;
	}
	
	@Override
	public View getView(int position, View view, ViewGroup parent) {
		
		LayoutInflater inflater = LayoutInflater.from(context);
		
		View row = inflater.inflate(resouce, parent, false);
		
		TextView title = row.findViewById(R.id.title);
		
		TextView work = row.findViewById(R.id.work);
		
		ModleClass modleClass = list.get(position);
		
		title.setText(modleClass.getTitle());
		
		work.setText(modleClass.getWork());
		
		return row;
	}
	
}